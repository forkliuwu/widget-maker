# Widget Maker — фото-виджеты 2×2, 2×4, 4×2 (Android, Kotlin + Compose + Glance)

1. Android Studio → New Project → Empty Activity (Compose).
   Name: WidgetMaker, package: com.example.widgetmaker, Min SDK 28.
2. В app/build.gradle.kts, в блок dependencies добавьте:
   implementation("androidx.glance:glance-appwidget:1.1.1")
3. Скопируйте файлы из архива поверх файлов проекта
   (AndroidManifest.xml, res/xml/widget_*.xml, .kt-файлы; шаблонный MainActivity.kt замените).
4. Sync Gradle → Run на телефоне.

Как пользоваться:
- Долгий тап по рабочему столу → Виджеты → Widget Maker → «Фото 2×2 / 2×4 / 4×2».
- Тап по виджету открывает приложение со списком ваших виджетов.
- Тап по виджету в списке → «Редактировать» (фото из галереи → масштабирование → «Готово»)
  или «Удалить виджет» (очищает фото; сам виджет с рабочего стола убирается вручную).

## Сборка APK без компьютера (GitHub Actions)
1. Создайте репозиторий на github.com.
2. Add file → Upload files → загрузите WidgetMaker.zip (без распаковки).
3. Add file → Create new file → имя .github/workflows/build.yml → вставьте содержимое
   файла из этого архива (WidgetMaker/.github/workflows/build.yml) → Commit.
4. Вкладка Actions → дождитесь зелёной галочки → в запуске внизу Artifacts → WidgetMaker-apk.
