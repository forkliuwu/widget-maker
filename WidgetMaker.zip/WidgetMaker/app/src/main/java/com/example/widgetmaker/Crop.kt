package com.example.widgetmaker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Загружаем фото с учётом поворота (EXIF) и уменьшаем до 2048 px по длинной стороне */
fun loadBitmap(ctx: Context, uri: Uri): Bitmap =
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val m = maxOf(info.size.width, info.size.height)
        if (m > 2048) {
            val k = 2048f / m
            decoder.setTargetSize(
                (info.size.width * k).roundToInt().coerceAtLeast(1),
                (info.size.height * k).roundToInt().coerceAtLeast(1)
            )
        }
    }

@Composable
fun CropScreen(uri: Uri, aspect: Float, onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    val ctx = LocalContext.current
    var src by remember(uri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(uri) {
        val r = withContext(Dispatchers.IO) { runCatching { loadBitmap(ctx, uri) }.getOrNull() }
        if (r == null) {
            Toast.makeText(ctx, "Не удалось открыть фото", Toast.LENGTH_SHORT).show()
            onCancel()
        } else src = r
    }
    val bmp = src
    if (bmp == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        Cropper(bmp, aspect, onCancel, onDone)
    }
}

@Composable
fun Cropper(bmp: Bitmap, aspect: Float, onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    val image = remember(bmp) { bmp.asImageBitmap() }
    val iw = bmp.width.toFloat()
    val ih = bmp.height.toFloat()
    // область фото, видимая при масштабе 1 (максимальная с пропорциями виджета)
    val baseW = if (iw / ih > aspect) ih * aspect else iw
    val baseH = baseW / aspect

    var zoom by remember { mutableStateOf(1f) }
    var cx by remember { mutableStateOf(iw / 2) } // центр рамки в координатах фото
    var cy by remember { mutableStateOf(ih / 2) }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Масштаб и положение", style = MaterialTheme.typography.headlineSmall)
        Text("Двигайте фото и сводите/разводите пальцы, чтобы изменить масштаб")
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            val fit = if (aspect >= 1f) Modifier.fillMaxWidth() else Modifier.fillMaxHeight()
            Canvas(
                fit.aspectRatio(aspect, matchHeightConstraintsFirst = aspect < 1f)
                    .clip(RoundedCornerShape(20.dp))
                    .pointerInput(bmp, aspect) {
                        detectTransformGestures { _, pan, gz, _ ->
                            zoom = (zoom * gz).coerceIn(1f, 8f)
                            val vw = baseW / zoom
                            val vh = baseH / zoom
                            cx -= pan.x * vw / size.width
                            cy -= pan.y * vh / size.height
                            cx = cx.coerceIn(vw / 2, maxOf(vw / 2, iw - vw / 2))
                            cy = cy.coerceIn(vh / 2, maxOf(vh / 2, ih - vh / 2))
                        }
                    }
            ) {
                val vw = baseW / zoom
                val vh = baseH / zoom
                drawImage(
                    image,
                    srcOffset = IntOffset((cx - vw / 2).roundToInt(), (cy - vh / 2).roundToInt()),
                    srcSize = IntSize(vw.roundToInt(), vh.roundToInt()),
                    dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                    filterQuality = FilterQuality.Medium
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onCancel) { Text("Отмена") }
            Button(onClick = {
                val vw = baseW / zoom
                val vh = baseH / zoom
                val w = vw.roundToInt().coerceIn(1, bmp.width)
                val h = vh.roundToInt().coerceIn(1, bmp.height)
                val x = (cx - vw / 2).roundToInt().coerceIn(0, bmp.width - w)
                val y = (cy - vh / 2).roundToInt().coerceIn(0, bmp.height - h)
                val cropped = Bitmap.createBitmap(bmp, x, y, w, h)
                // на виджет достаточно ~1000 px по длинной стороне
                val k = minOf(1f, 1000f / maxOf(w, h))
                val out = if (k < 1f) {
                    Bitmap.createScaledBitmap(
                        cropped,
                        (w * k).roundToInt().coerceAtLeast(1),
                        (h * k).roundToInt().coerceAtLeast(1),
                        true
                    )
                } else cropped
                onDone(out)
            }) { Text("Готово") }
        }
    }
}
