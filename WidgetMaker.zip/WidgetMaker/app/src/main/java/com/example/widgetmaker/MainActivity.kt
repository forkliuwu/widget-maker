package com.example.widgetmaker

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ---------- цвета ----------
val ACCENT = Color(0xFF5F50CC)

val DarkScheme = darkColorScheme(
    primary = ACCENT, onPrimary = Color.White,
    background = Color(0xFF0E0E0E), onBackground = Color.White,
    surface = Color(0xFF0E0E0E), onSurface = Color.White,
    surfaceVariant = Color(0xFF202020), onSurfaceVariant = Color.White   // карточки виджетов
)

val LightScheme = lightColorScheme(
    primary = ACCENT, onPrimary = Color.White,
    background = Color(0xFFF2F2F2), onBackground = Color.Black,
    surface = Color(0xFFF2F2F2), onSurface = Color.Black,
    surfaceVariant = Color(0xFF989898), onSurfaceVariant = Color.Black   // карточки виджетов
)

class MainActivity : ComponentActivity() {
    private var tick by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val system = isSystemInDarkTheme()
            var dark by remember { mutableStateOf(Prefs.darkOrNull(this@MainActivity) ?: system) }

            // цвет значков в статус-баре под выбранную тему
            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = !dark
                    isAppearanceLightNavigationBars = !dark
                }
            }

            MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme) {
                Surface(Modifier.fillMaxSize()) {
                    App(tick, dark) { value ->
                        dark = value
                        Prefs.setDark(this@MainActivity, value)
                    }
                }
            }
        }
    }

    // каждый раз при возврате в приложение обновляем виджеты и список
    override fun onResume() {
        super.onResume()
        WidgetUi.refreshAll(this)
        tick++
    }
}

/** Окно (диалог) с цветом фона по теме */
@Composable
fun DialogCard(dark: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = if (dark) Color(0xFF141414) else Color(0xFF989898),
            contentColor = if (dark) Color.White else Color.Black
        ) {
            Column(
                Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
        }
    }
}

/** Кнопка: в покое 202020 с белым текстом, при нажатии плавно меняет цвет на 5f50cc */
@Composable
fun PressButton(text: String, dark: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val scope = rememberCoroutineScope()
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    var flash by remember { mutableStateOf(false) } // чтобы смена цвета была видна и при быстром тапе

    val normal = if (dark) Color(0xFF202020) else Color(0xFFC9C9C9)
    val active = if (dark) ACCENT else Color(0xFF8C80E6)
    val bg by animateColorAsState(
        targetValue = if (pressed || flash) active else normal,
        animationSpec = tween(durationMillis = 300),
        label = "pressColor"
    )

    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable(interactionSource = source, indication = null) {
                if (!flash) {
                    flash = true
                    scope.launch {
                        delay(220)
                        onClick()
                        flash = false
                    }
                }
            }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (dark) Color.White else Color.Black, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun App(tick: Int, dark: Boolean, onDark: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<WidgetRef?>(null) }   // нажатый в списке виджет
    var renaming by remember { mutableStateOf<WidgetRef?>(null) }   // виджет, который переименовываем
    var pending by remember { mutableStateOf<WidgetRef?>(null) }    // ждём выбор фото из галереи
    var crop by remember { mutableStateOf<Pair<WidgetRef, Uri>?>(null) } // экран масштабирования

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val t = pending
        if (uri != null && t != null) crop = t to uri
        pending = null
    }

    val c = crop
    if (c != null) {
        CropScreen(
            uri = c.second,
            aspect = Photos.aspect(ctx, c.first),
            onCancel = { crop = null },
            onDone = { bmp ->
                Photos.save(ctx, c.first.id, bmp)
                WidgetUi.refresh(ctx, c.first.id)
                rev++
                crop = null
            }
        )
    } else {
        val widgets = remember(tick, rev) { Photos.existing(ctx) }
        LazyColumn(
            Modifier.safeDrawingPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text("Мои виджеты", style = MaterialTheme.typography.headlineMedium) }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Тёмная тема", Modifier.weight(1f))
                    Switch(
                        checked = dark,
                        onCheckedChange = onDark,
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = ACCENT,
                            checkedBorderColor = ACCENT,
                            checkedThumbColor = Color(0xFF2B2370),
                            uncheckedTrackColor = Color(0xFFD6D6D6),
                            uncheckedBorderColor = ACCENT,
                            uncheckedThumbColor = ACCENT
                        )
                    )
                }
            }
            if (widgets.isEmpty()) item {
                Text("На рабочем столе пока нет виджетов этого приложения. Добавьте: долгий тап по рабочему столу → Виджеты → Widget Maker.")
            }
            items(widgets, key = { it.id }) { t -> WidgetRow(t, tick, rev) { selected = t } }
        }

        selected?.let { t ->
            DialogCard(dark, onDismiss = { selected = null }) {
                Text(Prefs.name(ctx, t), style = MaterialTheme.typography.titleLarge)
                PressButton("Редактировать", dark, Modifier.fillMaxWidth()) {
                    pending = t
                    selected = null
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                PressButton("Переименовать", dark, Modifier.fillMaxWidth()) {
                    renaming = t
                    selected = null
                }
                PressButton("Удалить виджет", dark, Modifier.fillMaxWidth()) {
                    Photos.delete(ctx, t.id)
                    WidgetUi.refresh(ctx, t.id)
                    rev++
                    selected = null
                    Toast.makeText(
                        ctx,
                        "Фото убрано. Чтобы убрать виджет с рабочего стола, зажмите его и выберите «Удалить».",
                        Toast.LENGTH_LONG
                    ).show()
                }
                Text(
                    "«Удалить виджет» очистит фото. Сам виджет с рабочего стола Android позволяет убрать только вручную: зажмите его и выберите «Удалить».",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        renaming?.let { t ->
            var text by remember(t.id) { mutableStateOf(Prefs.name(ctx, t)) }
            DialogCard(dark, onDismiss = { renaming = null }) {
                Text("Название виджета", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ACCENT,
                        cursorColor = ACCENT
                    )
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PressButton("Отмена", dark, Modifier.weight(1f)) { renaming = null }
                    PressButton("Сохранить", dark, Modifier.weight(1f)) {
                        Prefs.setName(ctx, t.id, text)
                        renaming = null
                        rev++
                    }
                }
            }
        }
    }
}

@Composable
fun WidgetRow(t: WidgetRef, tick: Int, rev: Int, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp = remember(t.id, tick, rev) { Photos.load(ctx, t.id)?.asImageBitmap() }
    val aspect = remember(t.id, tick) { Photos.aspect(ctx, t) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(100.dp), contentAlignment = Alignment.Center) {
            val fit = if (aspect >= 1f) Modifier.fillMaxWidth() else Modifier.fillMaxHeight()
            Box(
                fit.aspectRatio(aspect, matchHeightConstraintsFirst = aspect < 1f)
                    .clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.background)
            ) {
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(Prefs.name(ctx, t), style = MaterialTheme.typography.titleMedium)
            Text(t.kind.replace('x', '×') + " · " + if (bmp != null) "фото выбрано" else "фото не выбрано")
        }
    }
}
