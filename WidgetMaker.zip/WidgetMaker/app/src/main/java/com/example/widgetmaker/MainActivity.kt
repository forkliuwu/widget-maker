package com.example.widgetmaker

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var tick by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App(tick) } } }
    }

    // каждый раз при возврате в приложение обновляем список виджетов
    override fun onResume() {
        super.onResume()
        tick++
    }
}

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var rev by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<WidgetRef?>(null) }   // нажатый в списке виджет
    var pending by remember { mutableStateOf<WidgetRef?>(null) }    // ждём выбор фото из галереи
    var crop by remember { mutableStateOf<Pair<WidgetRef, Uri>?>(null) } // экран масштабирования

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val t = pending
        if (uri != null && t != null) crop = t to uri
        pending = null
    }

    val c = crop
    if (c != null) {
        CropScreen(
            uri = c.second,
            aspect = Photos.aspect(ctx, c.first),
            onCancel = { crop = null },
            onDone = { bmp ->
                Photos.save(ctx, c.first.id, bmp)
                scope.launch { PhotoWidget().updateAll(ctx) }
                rev++
                crop = null
            }
        )
    } else {
        val widgets = remember(tick, rev) { Photos.existing(ctx) }
        LazyColumn(
            Modifier.safeDrawingPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text("Мои виджеты", style = MaterialTheme.typography.headlineMedium) }
            if (widgets.isEmpty()) item {
                Text("На рабочем столе пока нет виджетов этого приложения. Добавьте: долгий тап по рабочему столу → Виджеты → Widget Maker.")
            }
            items(widgets, key = { it.id }) { t -> WidgetRow(t, tick, rev) { selected = t } }
        }

        selected?.let { t ->
            AlertDialog(
                onDismissRequest = { selected = null },
                title = { Text("Виджет ${t.kind.replace('x', '×')}") },
                text = {
                    Text("«Удалить виджет» очистит фото. Сам виджет с рабочего стола Android позволяет убрать только вручную: зажмите его и выберите «Удалить».")
                },
                confirmButton = {
                    TextButton(onClick = {
                        pending = t
                        selected = null
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text("Редактировать") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        Photos.delete(ctx, t.id)
                        scope.launch { PhotoWidget().updateAll(ctx) }
                        rev++
                        selected = null
                        Toast.makeText(
                            ctx,
                            "Фото убрано. Чтобы убрать виджет с рабочего стола, зажмите его и выберите «Удалить».",
                            Toast.LENGTH_LONG
                        ).show()
                    }) { Text("Удалить виджет") }
                }
            )
        }
    }
}

@Composable
fun WidgetRow(t: WidgetRef, tick: Int, rev: Int, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp = remember(t.id, tick, rev) { Photos.load(ctx, t.id)?.asImageBitmap() }
    val aspect = remember(t.id, tick) { Photos.aspect(ctx, t) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(100.dp), contentAlignment = Alignment.Center) {
            val fit = if (aspect >= 1f) Modifier.fillMaxWidth() else Modifier.fillMaxHeight()
            Box(
                fit.aspectRatio(aspect, matchHeightConstraintsFirst = aspect < 1f)
                    .clip(RoundedCornerShape(12.dp)).background(Color.Gray)
            ) {
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text("Виджет ${t.kind.replace('x', '×')}", style = MaterialTheme.typography.titleMedium)
            Text(if (bmp != null) "Фото выбрано" else "Фото не выбрано")
        }
    }
}
