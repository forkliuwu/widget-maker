package com.example.widgetmaker

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    private var tick by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val system = isSystemInDarkTheme()
            var dark by remember { mutableStateOf(Prefs.darkOrNull(this@MainActivity) ?: system) }

            // цвет значков в статус-баре под выбранную тему
            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = !dark
                    isAppearanceLightNavigationBars = !dark
                }
            }

            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    App(tick, dark) { value ->
                        dark = value
                        Prefs.setDark(this@MainActivity, value)
                    }
                }
            }
        }
    }

    // каждый раз при возврате в приложение обновляем виджеты и список
    override fun onResume() {
        super.onResume()
        WidgetUi.refreshAll(this)
        tick++
    }
}

@Composable
fun App(tick: Int, dark: Boolean, onDark: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<WidgetRef?>(null) }   // нажатый в списке виджет
    var renaming by remember { mutableStateOf<WidgetRef?>(null) }   // виджет, который переименовываем
    var pending by remember { mutableStateOf<WidgetRef?>(null) }    // ждём выбор фото из галереи
    var crop by remember { mutableStateOf<Pair<WidgetRef, Uri>?>(null) } // экран масштабирования

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val t = pending
        if (uri != null && t != null) crop = t to uri
        pending = null
    }

    val c = crop
    if (c != null) {
        CropScreen(
            uri = c.second,
            aspect = Photos.aspect(ctx, c.first),
            onCancel = { crop = null },
            onDone = { bmp ->
                Photos.save(ctx, c.first.id, bmp)
                WidgetUi.refresh(ctx, c.first.id)
                rev++
                crop = null
            }
        )
    } else {
        val widgets = remember(tick, rev) { Photos.existing(ctx) }
        LazyColumn(
            Modifier.safeDrawingPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text("Мои виджеты", style = MaterialTheme.typography.headlineMedium) }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Тёмная тема", Modifier.weight(1f))
                    Switch(checked = dark, onCheckedChange = onDark)
                }
            }
            if (widgets.isEmpty()) item {
                Text("На рабочем столе пока нет виджетов этого приложения. Добавьте: долгий тап по рабочему столу → Виджеты → Widget Maker.")
            }
            items(widgets, key = { it.id }) { t -> WidgetRow(t, tick, rev) { selected = t } }
        }

        selected?.let { t ->
            AlertDialog(
                onDismissRequest = { selected = null },
                title = { Text(Prefs.name(ctx, t)) },
                text = {
                    Column {
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                pending = t
                                selected = null
                                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        ) { Text("Редактировать") }
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                renaming = t
                                selected = null
                            }
                        ) { Text("Переименовать") }
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                Photos.delete(ctx, t.id)
                                WidgetUi.refresh(ctx, t.id)
                                rev++
                                selected = null
                                Toast.makeText(
                                    ctx,
                                    "Фото убрано. Чтобы убрать виджет с рабочего стола, зажмите его и выберите «Удалить».",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        ) { Text("Удалить виджет") }
                        Text(
                            "«Удалить виджет» очистит фото. Сам виджет с рабочего стола Android позволяет убрать только вручную: зажмите его и выберите «Удалить».",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { selected = null }) { Text("Закрыть") } }
            )
        }

        renaming?.let { t ->
            var text by remember(t.id) { mutableStateOf(Prefs.name(ctx, t)) }
            AlertDialog(
                onDismissRequest = { renaming = null },
                title = { Text("Название виджета") },
                text = {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        Prefs.setName(ctx, t.id, text)
                        renaming = null
                        rev++
                    }) { Text("Сохранить") }
                },
                dismissButton = { TextButton(onClick = { renaming = null }) { Text("Отмена") } }
            )
        }
    }
}

@Composable
fun WidgetRow(t: WidgetRef, tick: Int, rev: Int, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp = remember(t.id, tick, rev) { Photos.load(ctx, t.id)?.asImageBitmap() }
    val aspect = remember(t.id, tick) { Photos.aspect(ctx, t) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(100.dp), contentAlignment = Alignment.Center) {
            val fit = if (aspect >= 1f) Modifier.fillMaxWidth() else Modifier.fillMaxHeight()
            Box(
                fit.aspectRatio(aspect, matchHeightConstraintsFirst = aspect < 1f)
                    .clip(RoundedCornerShape(12.dp)).background(Color.Gray)
            ) {
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(Prefs.name(ctx, t), style = MaterialTheme.typography.titleMedium)
            Text(t.kind.replace('x', '×') + " · " + if (bmp != null) "фото выбрано" else "фото не выбрано")
        }
    }
}
