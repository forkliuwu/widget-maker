package com.example.widgetmaker

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.glance.*
import androidx.glance.action.clickable
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider

class PhotoWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val appId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val bmp = Photos.load(context, appId)

        provideContent {
            val open = actionStartActivity<MainActivity>()
            if (bmp != null) {
                Image(
                    provider = ImageProvider(bmp),
                    contentDescription = null,
                    modifier = GlanceModifier.fillMaxSize().cornerRadius(20.dp).clickable(open),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    GlanceModifier.fillMaxSize().background(ColorProvider(Color(0xFF424242)))
                        .cornerRadius(20.dp).padding(8.dp).clickable(open),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Нажмите, чтобы выбрать фото",
                        style = TextStyle(color = ColorProvider(Color.White), textAlign = TextAlign.Center)
                    )
                }
            }
        }
    }
}

abstract class BaseReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = PhotoWidget()

    // виджет убрали с рабочего стола — удаляем его фото
    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        appWidgetIds.forEach { Photos.delete(context, it) }
    }
}

class Widget2x2Receiver : BaseReceiver()
class Widget2x4Receiver : BaseReceiver()
class Widget4x2Receiver : BaseReceiver()
