package com.example.widgetmaker

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.RemoteViews

/** Отрисовка виджета на рабочем столе (обычные RemoteViews, без сторонних библиотек) */
object WidgetUi {
    fun build(ctx: Context, id: Int): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_photo)
        val bmp = Photos.load(ctx, id)
        if (bmp != null) {
            v.setImageViewBitmap(R.id.img, rounded(bmp))
            v.setViewVisibility(R.id.img, View.VISIBLE)
            v.setViewVisibility(R.id.hint, View.GONE)
        } else {
            v.setViewVisibility(R.id.img, View.GONE)
            v.setViewVisibility(R.id.hint, View.VISIBLE)
        }
        val open = PendingIntent.getActivity(
            ctx,
            id,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        v.setOnClickPendingIntent(R.id.root, open)
        return v
    }

    fun refresh(ctx: Context, id: Int) {
        AppWidgetManager.getInstance(ctx).updateAppWidget(id, build(ctx, id))
    }

    fun refreshAll(ctx: Context) {
        Photos.existing(ctx).forEach { refresh(ctx, it.id) }
    }

    // скруглённые углы у фото
    private fun rounded(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        val r = minOf(src.width, src.height) * 0.13f
        Canvas(out).drawRoundRect(RectF(0f, 0f, src.width.toFloat(), src.height.toFloat()), r, r, paint)
        return out
    }
}

abstract class BaseReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { appWidgetManager.updateAppWidget(it, WidgetUi.build(context, it)) }
    }

    // виджет убрали с рабочего стола — удаляем его фото
    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach {
            Photos.delete(context, it)
            Prefs.setName(context, it, "")
        }
    }
}

class Widget2x2Receiver : BaseReceiver()
class Widget2x3Receiver : BaseReceiver()
class Widget2x4Receiver : BaseReceiver()
class Widget4x2Receiver : BaseReceiver()
