package com.example.widgetmaker

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/** Виджет, который сейчас стоит на рабочем столе: его id и размер ("2x2", "2x4", "4x2") */
data class WidgetRef(val id: Int, val kind: String)

object Photos {
    private fun file(c: Context, id: Int) = File(c.filesDir, "photo_$id.jpg")

    fun load(c: Context, id: Int): Bitmap? =
        file(c, id).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun save(c: Context, id: Int, bmp: Bitmap) {
        file(c, id).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    }

    fun delete(c: Context, id: Int) {
        file(c, id).delete()
    }

    /** Все виджеты приложения, которые сейчас есть на рабочем столе */
    fun existing(c: Context): List<WidgetRef> {
        val m = AppWidgetManager.getInstance(c)
        val kinds = listOf<Pair<String, Class<*>>>(
            "2x2" to Widget2x2Receiver::class.java,
            "2x4" to Widget2x4Receiver::class.java,
            "4x2" to Widget4x2Receiver::class.java
        )
        return kinds.flatMap { (k, cls) ->
            m.getAppWidgetIds(ComponentName(c, cls)).map { WidgetRef(it, k) }
        }.sortedBy { it.id }
    }

    /** Пропорции виджета (ширина / высота): реальные с рабочего стола, иначе по размеру */
    fun aspect(c: Context, t: WidgetRef): Float {
        val o = AppWidgetManager.getInstance(c).getAppWidgetOptions(t.id)
        val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        return if (w > 0 && h > 0) w.toFloat() / h else when (t.kind) {
            "2x4" -> 0.5f
            "4x2" -> 2f
            else -> 1f
        }
    }
}
